public class TestL00 {

   public static void main(String[] args) {
        TestUtils.runClass(TestHelloWorld.class);
    }

}
